# FINAL_NOTES

This bundle contains the finalized LaTeX paper and the exact evidence files used for every reported number.

## What was improved (relative to the provided draft)

- **Story + rigor**: Rewrote Abstract/Intro/Threat Model/Method/Metrics/Experiments/Limitations for a clearer, reviewer-friendly flow (problem → method → protocol → results → limitations).
- **Self-sufficiency**: Added explicit definitions for threat model, corruption operators, training objective (KD + identity + contraction), robustness/AUC metrics, and stability metrics; included a short training pseudocode block.
- **Claims discipline**: All quantitative statements in the main text/tables map to JSON in `evidence/**/metrics/*.json`. No new experiments, baselines, or numbers were invented.
- **Tables**: Improved captions and clarified that the primary evaluation is **OOD held-out `contiguous_overwrite`** under LOTO. Added an appendix per-task table so the aggregate score is transparent.
- **Figures**: Regenerated all main figures (`figA`–`figD`) from the existing evidence JSON with improved typography/labels/DPI and a consistent theme (data unchanged).
- **Build robustness**: Replaced BibTeX-dependent bibliography with an in-project `paper/bibliography.tex` generated from the existing `paper/refs.bib` entries so the project compiles in minimal environments.

## Claim-to-evidence pointers (primary numbers)

All paths are relative to the bundle root.

### Primary model (gpt2-medium)

Source: `evidence/gpt2_medium_contr/metrics/task_metrics.json`

- Clean score:
  - CacheMedic++: `metrics.clean_regression.cachemedic` = 0.2466
  - No defense: `metrics.clean_regression.no_defense` = 0.2373
  - Best heuristic (smoothing): `metrics.clean_regression.best_heuristic` = 0.2373
- Robustness AUC:
  - CacheMedic++: `metrics.robustness_auc.cachemedic` = 0.0401
  - No defense: `metrics.robustness_auc.no_defense` = 0.0384
  - Best heuristic (smoothing): `metrics.robustness_auc.best_heuristic` = 0.0390
- Best heuristic name:
  - `metrics.best_heuristic_name` = "smoothing"

### Paired contraction ablation (gpt2-medium)

Sources:
- `evidence/gpt2_medium_no_contr/metrics/task_metrics.json` (no_contr)
- `evidence/gpt2_medium_contr/metrics/task_metrics.json` (contr)
- `evidence/gpt2_medium_no_contr/metrics/stability_metrics.json`
- `evidence/gpt2_medium_contr/metrics/stability_metrics.json`

- Robustness AUC:
  - no_contr: `metrics.robustness_auc.cachemedic` = 0.0388
  - contr:   `metrics.robustness_auc.cachemedic` = 0.0401
- Logit sensitivity values used for the stability ratios:
  - no_contr: `metrics["stability.logit_sensitivity"]` (delta_norm=1.0 and 2.0) → `cachemedic`
  - contr:    `metrics["stability.logit_sensitivity"]` (delta_norm=1.0 and 2.0) → `cachemedic`
- Stability ratios (contr / no_contr):
  - delta=1.0: 0.9291
  - delta=2.0: 0.9266  
  (Computed directly from the two stability JSON files above; the final values are also rendered in `paper/tables/table_ablation_summary.tex`.)

### Second model (gpt2-large)

Source: `evidence/gpt2_large_contr/metrics/task_metrics.json`

- Clean score:
  - CacheMedic++: `metrics.clean_regression.cachemedic` = 0.3001
  - No defense:  `metrics.clean_regression.no_defense` = 0.2974
- Robustness AUC:
  - CacheMedic++: `metrics.robustness_auc.cachemedic` = 0.0475
  - No defense:  `metrics.robustness_auc.no_defense` = 0.0472

## Known remaining limitations (explicit in the paper)

- **Absolute stability vs unmodified baseline is not the central win.** The strongest stability evidence is the paired contraction-vs-no_contr ablation plus the robustness/clean tradeoff and second-model qualitative transfer.
- The threat model uses deterministic simulated cache corruptions; it is not a claim about real hardware fault distributions or a complete adversarial security guarantee.
- The bundled needle-style probe yields 0 accuracy across methods in this configuration; aggregate-score changes are therefore driven by WT2 + SST-2.
